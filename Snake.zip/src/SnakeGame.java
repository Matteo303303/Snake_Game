 
public class SnakeGame {

	public static void main(String[] args) {
		GameFrame frame = new GameFrame();//GameFrame()=costruttore (metodo chiamato alla creazione di un istanza)
			 	
		//creo la finestra

	}

}
